package com.arshia.alarambyarshia;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONException;
import org.json.JSONObject;

public class Home extends AppCompatActivity {

    private static final String TAG="tag";

    String url;
    String tag_json_obj = "json_obj_req";
    ProgressDialog pDialog;
    TextView fajar,zuhar,Asar,Maghrib,isha, locationn,time;
    EditText userinput;
    Button btn;
    Button listbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        fajar=(TextView) findViewById(R.id.Fajrtv);
        zuhar=(TextView) findViewById(R.id.Dhurtv);
        Asar=(TextView) findViewById(R.id.Asrtv);
        Maghrib=(TextView) findViewById(R.id.Magribtv);
        isha=(TextView) findViewById(R.id.Ishatv);
        time=(TextView) findViewById(R.id.Date);
        locationn =(TextView) findViewById(R.id.Location);
        userinput=(EditText)findViewById(R.id.userinput);
        btn=(Button)findViewById(R.id.search);
        listbtn=(Button)findViewById(R.id.list);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mLocation = userinput.getText().toString().trim();

                if(mLocation.isEmpty())
                {
                    Toast.makeText(Home.this, "Please Enter Location", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    url="https://muslimsalat.com/"+mLocation+".json?key=58f382d1241e8916e942157ab673037f";
                    searchLocation();
                }
            }
        });

    }
    public void gotoGoodDeeds(View view) {
        Intent intent = new Intent(this, GoodDeeds.class);
        startActivity(intent);
    }


    private void searchLocation() {


        pDialog = new ProgressDialog(this);
        pDialog.setMessage("Loading...");
        pDialog.show();

        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.GET,
                url, null,
                new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {

                        try {

                            String country=response.get("country").toString();
                            String state= response.get("state").toString();
                            String city = response.get("city").toString();
                            String mlocation= country + "," + state + "" + city;

                            String date= response.getJSONArray("items").getJSONObject(0).get("date_for").toString();


                            String mfajar= response.getJSONArray("items").getJSONObject(0).get("fajr").toString();
                            String mzuhr= response.getJSONArray("items").getJSONObject(0).get("dhuhr").toString();
                            String masar= response.getJSONArray("items").getJSONObject(0).get("asr").toString();
                            String mmaghrib= response.getJSONArray("items").getJSONObject(0).get("maghrib").toString();
                            String misha= response.getJSONArray("items").getJSONObject(0).get("isha").toString();

                            fajar.setText(mfajar);
                            zuhar.setText(mzuhr);
                            Asar.setText(masar);
                            Maghrib.setText(mmaghrib);
                            isha.setText(misha);
                            locationn.setText(mlocation);
                            time.setText(date);




                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        pDialog.hide();
                    }
                }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                Toast.makeText(Home.this, "Error", Toast.LENGTH_SHORT).show();

                // hide the progress dialog
                pDialog.hide();
            }
        });

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(jsonObjReq, tag_json_obj);
    }
}